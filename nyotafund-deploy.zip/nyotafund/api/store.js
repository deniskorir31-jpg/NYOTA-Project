// store.js — Shared in-memory data store
// ⚠️  In production replace with a real database (Firebase, Supabase, PlanetScale, Vercel KV)
// For Vercel serverless, each function invocation may spin up a fresh instance,
// so this store is best used with Vercel KV or an external DB for persistence.

if (!global._nyotaStore) {
  global._nyotaStore = {
    payments: [],      // { id, checkoutRequestID, phone, amount, loanType, mpesaCode, paidAt, status, applicationId }
    applications: [],  // { id, firstName, lastName, phone, nationalId, loanType, amount, purpose, email, paymentId, submittedAt, status }
  };
}

module.exports = global._nyotaStore;
