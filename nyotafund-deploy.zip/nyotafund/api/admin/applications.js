// api/admin/applications.js — Admin: list applications and approve/reject
const store = require("../store");

function checkAuth(req, res) {
  const secret = req.headers["x-admin-secret"];
  if (!secret || secret !== process.env.ADMIN_SECRET) {
    res.status(401).json({ error: "Unauthorized. Provide correct x-admin-secret header." });
    return false;
  }
  return true;
}

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, PATCH, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, x-admin-secret");
  if (req.method === "OPTIONS") return res.status(200).end();
  if (!checkAuth(req, res)) return;

  // GET — list all applications with their payment info
  if (req.method === "GET") {
    const applications = store.applications.map(app => {
      const payment = store.payments.find(p => p.checkoutRequestID === app.checkoutRequestID);
      return { ...app, payment: payment || null };
    });

    // Sort newest first
    applications.sort((a, b) => new Date(b.submittedAt) - new Date(a.submittedAt));

    return res.status(200).json({
      total: applications.length,
      pending: applications.filter(a => a.status === "pending_review").length,
      approved: applications.filter(a => a.status === "approved").length,
      rejected: applications.filter(a => a.status === "rejected").length,
      applications,
    });
  }

  // PATCH — update application status
  if (req.method === "PATCH") {
    const { id, status, adminNotes } = req.body;

    if (!id || !status) {
      return res.status(400).json({ error: "id and status are required" });
    }

    const validStatuses = ["pending_review", "approved", "rejected", "more_info_needed"];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: `status must be one of: ${validStatuses.join(", ")}` });
    }

    const app = store.applications.find(a => a.id === id);
    if (!app) return res.status(404).json({ error: "Application not found" });

    app.status = status;
    app.adminNotes = adminNotes || app.adminNotes;
    app.reviewedAt = new Date().toISOString();

    console.log(`👤 Admin updated ${id} → ${status}`);

    return res.status(200).json({ success: true, application: app });
  }

  res.status(405).json({ error: "Method not allowed" });
};
