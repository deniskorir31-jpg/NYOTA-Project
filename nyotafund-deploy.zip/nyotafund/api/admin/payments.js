// api/admin/payments.js — Admin: view all payments
const store = require("../store");

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "x-admin-secret");
  if (req.method === "OPTIONS") return res.status(200).end();

  const secret = req.headers["x-admin-secret"];
  if (!secret || secret !== process.env.ADMIN_SECRET) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const payments = [...store.payments].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.status(200).json({ total: payments.length, payments });
};
