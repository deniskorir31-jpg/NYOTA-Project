// api/mpesa/callback.js — Receives payment confirmation from Safaricom
const store = require("../store");

module.exports = async function handler(req, res) {
  // Safaricom sends a POST with the payment result
  if (req.method !== "POST") return res.status(405).end();

  try {
    const body = req.body;
    console.log("M-Pesa Callback received:", JSON.stringify(body, null, 2));

    const callback = body?.Body?.stkCallback;
    if (!callback) {
      return res.status(400).json({ ResultCode: 1, ResultDesc: "Invalid callback body" });
    }

    const { ResultCode, ResultDesc, CheckoutRequestID, MerchantRequestID, CallbackMetadata } = callback;

    // Find the pending payment record
    const payment = store.payments.find(p => p.checkoutRequestID === CheckoutRequestID);

    if (!payment) {
      // Record it anyway so nothing is lost
      console.warn("Payment not found in store for CheckoutRequestID:", CheckoutRequestID);
    }

    if (ResultCode === 0) {
      // SUCCESS — extract metadata from Safaricom
      const items = CallbackMetadata?.Item || [];
      const getMeta = (name) => items.find(i => i.Name === name)?.Value;

      const mpesaCode    = getMeta("MpesaReceiptNumber");
      const paidAmount   = getMeta("Amount");
      const paidPhone    = getMeta("PhoneNumber");
      const paidAt       = getMeta("TransactionDate");

      if (payment) {
        payment.status       = "paid";
        payment.mpesaCode    = mpesaCode;
        payment.paidAmount   = paidAmount;
        payment.paidPhone    = paidPhone;
        payment.paidAt       = paidAt ? String(paidAt) : new Date().toISOString();
      } else {
        // Add fresh record from callback data
        store.payments.push({
          checkoutRequestID: CheckoutRequestID,
          merchantRequestID: MerchantRequestID,
          mpesaCode,
          paidAmount,
          phone: paidPhone,
          status: "paid",
          paidAt: paidAt ? String(paidAt) : new Date().toISOString(),
          loanType: "Unknown",
          createdAt: new Date().toISOString(),
        });
      }

      console.log(`✅ Payment confirmed: ${mpesaCode} | KES ${paidAmount} | ${paidPhone}`);
    } else {
      // FAILED or CANCELLED
      if (payment) {
        payment.status = "failed";
        payment.failReason = ResultDesc;
      }
      console.log(`❌ Payment failed: ${ResultDesc}`);
    }

    // Always respond 200 to Safaricom or they will keep retrying
    res.status(200).json({ ResultCode: 0, ResultDesc: "Accepted" });
  } catch (err) {
    console.error("Callback error:", err);
    // Still respond 200 to avoid Safaricom retries
    res.status(200).json({ ResultCode: 0, ResultDesc: "Accepted" });
  }
};
