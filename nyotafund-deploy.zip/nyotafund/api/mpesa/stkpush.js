// api/mpesa/stkpush.js — Initiates M-Pesa STK Push payment
const fetch = require("node-fetch");
const store = require("../store");

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  try {
    const { phone, amount, loanType, applicantName } = req.body;

    // Validate inputs
    if (!phone || !amount || !loanType) {
      return res.status(400).json({ error: "phone, amount, and loanType are required" });
    }

    const { MPESA_SHORTCODE, MPESA_PASSKEY, MPESA_CALLBACK_URL, MPESA_ENV } = process.env;

    if (!MPESA_SHORTCODE || !MPESA_PASSKEY || !MPESA_CALLBACK_URL) {
      return res.status(500).json({ error: "M-Pesa not fully configured. Check MPESA_SHORTCODE, MPESA_PASSKEY, MPESA_CALLBACK_URL in Vercel env vars." });
    }

    // Get OAuth token
    const baseUrl = MPESA_ENV === "production"
      ? "https://api.safaricom.co.ke"
      : "https://sandbox.safaricom.co.ke";

    const auth = Buffer.from(`${process.env.MPESA_CONSUMER_KEY}:${process.env.MPESA_CONSUMER_SECRET}`).toString("base64");
    const tokenRes = await fetch(`${baseUrl}/oauth/v1/generate?grant_type=client_credentials`, {
      headers: { Authorization: `Basic ${auth}` }
    });
    const tokenData = await tokenRes.json();
    const token = tokenData.access_token;

    if (!token) {
      return res.status(500).json({ error: "Could not get M-Pesa token" });
    }

    // Build timestamp & password
    const timestamp = new Date().toISOString().replace(/[^0-9]/g, "").slice(0, 14);
    const password = Buffer.from(`${MPESA_SHORTCODE}${MPESA_PASSKEY}${timestamp}`).toString("base64");

    // Normalize phone number to 254XXXXXXXXX
    let formattedPhone = phone.replace(/\s+/g, "").replace(/^\+/, "");
    if (formattedPhone.startsWith("0")) formattedPhone = "254" + formattedPhone.slice(1);
    if (!formattedPhone.startsWith("254")) formattedPhone = "254" + formattedPhone;

    const accountRef = `NYOTA-${Date.now()}`;

    const stkBody = {
      BusinessShortCode: MPESA_SHORTCODE,
      Password: password,
      Timestamp: timestamp,
      TransactionType: "CustomerPayBillOnline",
      Amount: Math.ceil(Number(amount)),
      PartyA: formattedPhone,
      PartyB: MPESA_SHORTCODE,
      PhoneNumber: formattedPhone,
      CallBackURL: MPESA_CALLBACK_URL,
      AccountReference: accountRef,
      TransactionDesc: `NyotaFund ${loanType} Registration Fee`,
    };

    const mpesaRes = await fetch(`${baseUrl}/mpesa/stkpush/v1/processrequest`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(stkBody),
    });

    const result = await mpesaRes.json();
    console.log("STK Push result:", result);

    if (result.ResponseCode === "0") {
      // Record pending payment in store
      store.payments.push({
        checkoutRequestID: result.CheckoutRequestID,
        merchantRequestID: result.MerchantRequestID,
        phone: formattedPhone,
        amount: Number(amount),
        loanType,
        applicantName: applicantName || "",
        status: "pending",
        createdAt: new Date().toISOString(),
      });

      return res.status(200).json({
        success: true,
        checkoutRequestID: result.CheckoutRequestID,
        message: "STK Push sent successfully. Check your phone and enter your M-Pesa PIN.",
      });
    } else {
      return res.status(400).json({
        success: false,
        message: result.errorMessage || result.ResponseDescription || "STK Push failed",
        detail: result,
      });
    }
  } catch (err) {
    console.error("STK Push error:", err);
    res.status(500).json({ error: "Internal server error", message: err.message });
  }
};
