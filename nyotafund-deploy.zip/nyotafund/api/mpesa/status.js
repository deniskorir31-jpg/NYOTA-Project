// api/mpesa/status.js — Frontend polls this to check if payment went through
const store = require("../store");

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  if (req.method !== "GET") return res.status(405).end();

  const { id } = req.query;
  if (!id) return res.status(400).json({ error: "Missing checkout request ID" });

  const payment = store.payments.find(p => p.checkoutRequestID === id);

  if (!payment) {
    return res.status(200).json({ paid: false, status: "pending" });
  }

  res.status(200).json({
    paid: payment.status === "paid",
    status: payment.status,
    mpesaCode: payment.mpesaCode || null,
    amount: payment.paidAmount || payment.amount,
    phone: payment.paidPhone || payment.phone,
  });
};
