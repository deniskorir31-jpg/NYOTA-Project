// api/mpesa/token.js — Fetches Safaricom OAuth access token
const fetch = require("node-fetch");

module.exports = async function handler(req, res) {
  // Allow CORS for internal calls
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  if (req.method === "OPTIONS") return res.status(200).end();

  try {
    const { MPESA_CONSUMER_KEY, MPESA_CONSUMER_SECRET, MPESA_ENV } = process.env;

    if (!MPESA_CONSUMER_KEY || !MPESA_CONSUMER_SECRET) {
      return res.status(500).json({ error: "M-Pesa credentials not configured. Set MPESA_CONSUMER_KEY and MPESA_CONSUMER_SECRET in Vercel environment variables." });
    }

    const auth = Buffer.from(`${MPESA_CONSUMER_KEY}:${MPESA_CONSUMER_SECRET}`).toString("base64");

    // Use sandbox for testing, production for live
    const baseUrl = MPESA_ENV === "production"
      ? "https://api.safaricom.co.ke"
      : "https://sandbox.safaricom.co.ke";

    const response = await fetch(
      `${baseUrl}/oauth/v1/generate?grant_type=client_credentials`,
      {
        method: "GET",
        headers: { Authorization: `Basic ${auth}` },
      }
    );

    const data = await response.json();

    if (!data.access_token) {
      return res.status(500).json({ error: "Failed to get token", detail: data });
    }

    res.status(200).json({ token: data.access_token });
  } catch (err) {
    console.error("Token error:", err);
    res.status(500).json({ error: "Internal server error", message: err.message });
  }
};
