// api/applications/submit.js — Saves loan application after payment is confirmed
const store = require("../store");

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  try {
    const {
      firstName, lastName, phone, nationalId,
      loanType, amount, purpose, email,
      checkoutRequestID
    } = req.body;

    // Validate required fields
    const required = { firstName, lastName, phone, nationalId, loanType, amount, purpose, email, checkoutRequestID };
    const missing = Object.entries(required).filter(([, v]) => !v).map(([k]) => k);
    if (missing.length > 0) {
      return res.status(400).json({ error: `Missing required fields: ${missing.join(", ")}` });
    }

    // Verify payment is confirmed
    const payment = store.payments.find(p => p.checkoutRequestID === checkoutRequestID);
    if (!payment) {
      return res.status(400).json({ error: "Payment not found. Please complete M-Pesa payment first." });
    }
    if (payment.status !== "paid") {
      return res.status(400).json({ error: "Payment not confirmed yet. Please wait or try again." });
    }

    // Check this payment hasn't already been used for an application
    const existingApp = store.applications.find(a => a.checkoutRequestID === checkoutRequestID);
    if (existingApp) {
      return res.status(400).json({ error: "This payment has already been used for an application." });
    }

    const applicationId = `APP-${Date.now()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;

    const application = {
      id: applicationId,
      firstName,
      lastName,
      phone,
      nationalId,
      loanType,
      amount: Number(amount),
      purpose,
      email,
      checkoutRequestID,
      mpesaCode: payment.mpesaCode,
      feePaid: payment.paidAmount || payment.amount,
      submittedAt: new Date().toISOString(),
      status: "pending_review", // admin will update to approved / rejected
      adminNotes: "",
    };

    store.applications.push(application);

    // Link payment to application
    payment.applicationId = applicationId;

    console.log(`📋 New application: ${applicationId} | ${firstName} ${lastName} | ${loanType} | KES ${amount}`);

    res.status(200).json({
      success: true,
      applicationId,
      message: "Application submitted successfully. Our team will review and contact you within 24 hours.",
    });
  } catch (err) {
    console.error("Application submit error:", err);
    res.status(500).json({ error: "Internal server error", message: err.message });
  }
};
