# NyotaFund — Deployment Guide

## Project Structure

```
nyotafund/
├── public/
│   ├── index.html        ← Main website with M-Pesa payment integration
│   └── admin.html        ← Admin dashboard (password protected)
├── api/
│   ├── store.js          ← In-memory data store (replace with DB in production)
│   ├── mpesa/
│   │   ├── token.js      ← Fetches Safaricom OAuth token
│   │   ├── stkpush.js    ← Sends STK Push to user's phone
│   │   ├── callback.js   ← Receives payment confirmation from Safaricom
│   │   └── status.js     ← Frontend polls this to check payment status
│   ├── applications/
│   │   └── submit.js     ← Saves loan application after payment
│   └── admin/
│       ├── applications.js ← Admin: list & approve/reject applications
│       └── payments.js     ← Admin: view all payments
├── package.json
├── vercel.json
└── README.md
```

---

## Step 1 — Get Safaricom Daraja API Credentials

1. Go to https://developer.safaricom.co.ke
2. Create an account and log in
3. Click "Create App" → name it "NyotaFund"
4. Select "Lipa Na M-Pesa Sandbox" product
5. Copy your **Consumer Key** and **Consumer Secret**
6. Go to "APIs" → "Lipa Na M-Pesa" → copy your **Passkey**
7. Note your **Business Shortcode** (for sandbox: 174379)

---

## Step 2 — Deploy to Vercel

### Option A — Using Vercel CLI (recommended)

```bash
npm install -g vercel
cd nyotafund
vercel login
vercel
```

Follow the prompts. When asked about settings, accept defaults.

### Option B — GitHub + Vercel Dashboard

1. Create a GitHub repo and push this folder
2. Go to https://vercel.com → "New Project"
3. Import your GitHub repo
4. Click "Deploy"

---

## Step 3 — Set Environment Variables

In Vercel Dashboard → Your Project → Settings → Environment Variables, add:

| Variable Name          | Value                                              |
|------------------------|----------------------------------------------------|
| MPESA_CONSUMER_KEY     | (from Daraja dashboard)                            |
| MPESA_CONSUMER_SECRET  | (from Daraja dashboard)                            |
| MPESA_SHORTCODE        | 174379 (sandbox) or your real paybill/till         |
| MPESA_PASSKEY          | (from Daraja dashboard)                            |
| MPESA_CALLBACK_URL     | https://YOUR-VERCEL-URL.vercel.app/api/mpesa/callback |
| MPESA_ENV              | sandbox (change to "production" when going live)   |
| ADMIN_SECRET           | (choose a strong password for admin dashboard)     |

⚠️ Replace YOUR-VERCEL-URL with your actual Vercel deployment URL.

---

## Step 4 — Redeploy After Setting Env Vars

After adding environment variables, trigger a new deployment:
- Vercel Dashboard → Deployments → "Redeploy"

---

## Step 5 — Test in Sandbox

1. Visit your site
2. Click "Apply Now" for any loan type
3. Use Safaricom sandbox test number: **0708374149**
4. STK Push will simulate — no real money charged
5. Check admin dashboard at `/admin` with your ADMIN_SECRET password

---

## Step 6 — Go Live (Production)

1. Register for a live Safaricom M-Pesa account at https://developer.safaricom.co.ke
2. Update environment variables:
   - `MPESA_ENV` → `production`
   - `MPESA_SHORTCODE` → your real business shortcode
   - `MPESA_PASSKEY` → your real passkey
   - `MPESA_CONSUMER_KEY` / `MPESA_CONSUMER_SECRET` → production credentials
3. Redeploy on Vercel

---

## Admin Dashboard

Access at: **https://YOUR-SITE.vercel.app/admin**

Login with the `ADMIN_SECRET` password you set.

Features:
- View all loan applications with payment status
- Approve / Reject / Request more info
- Add admin notes per application
- View all M-Pesa payments separately
- Auto-refreshes every 60 seconds

---

## Registration Fees (configured in public/index.html)

| Loan Type      | Fee (KES) |
|----------------|-----------|
| Personal Loan  | 300       |
| Business Loan  | 500       |
| Emergency Loan | 200       |

To change fees, edit the `FEES` object in `public/index.html`:
```javascript
const FEES = { "Personal Loan": 300, "Business Loan": 500, "Emergency Loan": 200 };
```

---

## Important Notes

### Data Persistence
The current setup uses an in-memory store. This means data resets on each Vercel cold start.

For production, replace `api/store.js` with one of:
- **Vercel KV** (easiest) — https://vercel.com/docs/storage/vercel-kv
- **Firebase Firestore** — https://firebase.google.com
- **Supabase** (PostgreSQL) — https://supabase.com
- **PlanetScale** (MySQL) — https://planetscale.com

### Security
- The admin dashboard uses a simple password header. For production, consider JWT auth.
- Add rate limiting to the STK Push endpoint to prevent abuse.
- Keep your ADMIN_SECRET strong (16+ characters, mix of letters/numbers/symbols).

### Safaricom Callback
Safaricom needs to reach your server to confirm payments. Make sure:
1. Your MPESA_CALLBACK_URL is publicly accessible (Vercel handles this)
2. The URL does NOT require authentication
3. Your server always returns HTTP 200 to the callback

---

## Support

For Safaricom Daraja API issues: https://developer.safaricom.co.ke/Support
For Vercel deployment issues: https://vercel.com/docs
